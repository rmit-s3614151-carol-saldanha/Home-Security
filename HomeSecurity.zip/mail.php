<?php 
  
//require_once("./PHPMailerAutoload.php");
  require_once("./mail_config.php");
  session_start();
    //  $operation = 1;//$_POST['isID'];
 
  $to = "sebytom31@gmail.com, eashantilve93@gmail.com";
  $subject = "Home Security: Alert";

  $message =  '<!DOCTYPE html>
                <html>
                  <head>

                  </head>

                  <body>
                    <h1>Suspicious Activity Detected at your residence</h1>
                     <a href="http://test-env.yuwdtxni2q.us-east-2.elasticbeanstalk.com/" ><h2>Click to control your Home Security </h2> </a>
                  </body>
                  </html>'; 
                // Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                // More headers
                $headers .= "Reply-To: The Sender <cloudComputingChiron@gmail.com>\r\n"; 
                $headers .= "Return-Path: The Sender <cloudComputingChiron@gmail.com>\r\n"; 
                $headers .= "From: The Sender <cloudComputingChiron@gmail.com>\r\n"; 
                  
                 mail($to,$subject,$message,$headers) ;
                
                $_SESSION['status'] = 1 ;

                header("Location: http://test-env.yuwdtxni2q.us-east-2.elasticbeanstalk.com/");

?> 