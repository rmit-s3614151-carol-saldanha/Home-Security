<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
   <title>Home Security</title>
  
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
  
  
<!-- CSS Script -->
    <link rel="stylesheet" type="text/css" href="./index.css">
</head>
<body>

    <div class="jumbotron text-center">
        <h2>Home Security: Alarm Deactivated</h2>
    </div>
<div class="container">
 <center>
      <a href="./index.php"><button class="button">Home&nbsp;&nbsp;<span class="glyphicon glyphicon-home"></button> </a>
  <hr>
  <div >
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/0.jpg">
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/1.jpg">
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/2.jpg"> 

  </div> 
  <div >
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/3.jpg">
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/4.jpg">
     <img class= "img" src="https://s3.us-east-2.amazonaws.com/elasticbeanstalk-us-east-2-836233521447/pics/5.jpg"> 
  </div> <br>
       
</center>
<?php
  require 'vendor/autoload.php';

  $credentials = new Aws\Credentials\Credentials('AKIAJEBSLAXMB5SRPRRA','Mb25ikdrAilrf+D9jEIf1yHhjWIZpX4pXoQ4QKf9');

  $s3 = new Aws\S3\S3Client([
      'version'     => 'latest',
      'region'      => 'us-east-2',
      'credentials' => $credentials
  ]);


  // Register the stream wrapper from an S3Client object
  $s3->registerStreamWrapper();

  file_put_contents('s3://elasticbeanstalk-us-east-2-836233521447/files/test.txt', 'alarmOff');

header("Location: http://test-env.yuwdtxni2q.us-east-2.elasticbeanstalk.com/");
?>
</div>
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

</body>
</html>
