<?php 
		
		// LOAD THE PHP MAILER 
		require_once './PHPMailer-master/PHPMailerAutoload.php';



		$mail = new PHPMailer;

		//Enable SMTP debugging. 
		//$mail->SMTPDebug = true;                               
		//Set PHPMailer to use SMTP.
		$mail->isSMTP();            
		//Set SMTP host name                          
		$mail->Host = "smtp.gmail.com";
		//Set this to true if SMTP host requires authentication to send email
		$mail->SMTPAuth = true;                          
		//Provide username and password     
		$mail->Username = "cloudComputingChiron@gmail.com";                 
		$mail->Password = "!@#4cloudcomputingchiron";                           
		//If SMTP requires TLS encryption then set it
		$mail->SMTPSecure = "tls";                           
		//Set TCP port to connect to 
		$mail->Port = 587;        

		//From email address and name
		$mail->From = "cloudComputingChiron@gmail.com";
		$mail->FromName = "Home Security";


		//To address and name
		$mail->addAddress("sebytom31@gmail.com" , "Seby Tom"); //Recipient name is optional
		$mail->addAddress("eashantilve93@gmail.com" , "Eashan Tilve");


		$mail->isHTML(true);

	
?>